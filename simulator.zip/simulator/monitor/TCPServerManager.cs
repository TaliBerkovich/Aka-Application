﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace monitor
{
    public delegate void receivedMessage(string text);

    public class TCPServerManager
    {
        TcpListener listener;
        TcpClient client;
        public event receivedMessage receiveMessageEvent;
        string ipAddress;
        int port;

        public TCPServerManager(string ipIddress, int port)
        {
            ipAddress = ipIddress;
            this.port = port;
        }
        public void RunReceiveStream()
        {
            IPAddress localAdd = IPAddress.Parse(ipAddress);
            listener = new TcpListener(port);
            listener.Start();
            client = listener.AcceptTcpClient();
            try
            {
                while (true)
                {
                    NetworkStream nwStream = client.GetStream();
                    byte[] buffer = new byte[client.ReceiveBufferSize];
                    int bytesRead = nwStream.Read(buffer, 0, client.ReceiveBufferSize);
                    string dataReceived = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    if (dataReceived.Length > 0)
                    {
                        receiveMessageEvent?.Invoke(dataReceived);
                    }                
                }
            }
            catch (Exception e)
            {
                CloseClient();
            }
        }

        public void CloseClient()
        {
            if (client != null)
            {
                client.Close();
            }
            if (listener != null)
            {
                listener.Stop();
            }
        }
    }
}
