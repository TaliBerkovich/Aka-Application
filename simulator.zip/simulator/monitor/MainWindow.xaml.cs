﻿using System.ComponentModel; // CancelEventArgs
using System.Linq;
using System.Threading;
using System.Windows;

namespace monitor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window, INotifyPropertyChanged
    {
        
        MonitorManager monitorManeger;       
        int numMesegesforUiPrinting = 0;
        bool isNumMesegesinitialized =  false;

        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = this;
            uiContent = string.Empty;

            monitorManeger = new MonitorManager();
            var newThread = new Thread(monitorManeger.Run);
            newThread.Name = "Working Thread";
            newThread.Priority = ThreadPriority.AboveNormal;
            newThread.Start();

            monitorManeger.receiveMessageEvent += WriteToTextbox;
        }
        
        delegate void ParametrizedMethodInvoker(string arg);
        public event PropertyChangedEventHandler PropertyChanged;

        public string uiContent { get; set; }

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        void WriteToTextbox(string text)
        {
            string[] currentExistingMessages;
            string messagesForDisplay;

            if (!(isNumMesegesinitialized))
            {
                numMesegesforUiPrinting = monitorManeger.GetUiConfiguration();
                isNumMesegesinitialized = true;
            }
            
            if (!Dispatcher.CheckAccess()) 
            {
                Dispatcher.Invoke(new ParametrizedMethodInvoker(WriteToTextbox), text);
                return;
            }
            messagesForDisplay = uiContent + text;
            currentExistingMessages = messagesForDisplay.Split(System.Environment.NewLine);
            if (currentExistingMessages.Length - 1 > numMesegesforUiPrinting)
            {
                messagesForDisplay = string.Join(System.Environment.NewLine, currentExistingMessages.Where((item, index) => index > (currentExistingMessages.Length - numMesegesforUiPrinting - 1)));
            }
            uiContent = messagesForDisplay;
            OnPropertyChanged("uiContent");
        }

        void WindowClosing(object sender, CancelEventArgs e)
        {
            monitorManeger.CloseClient();
        }

    }
}
