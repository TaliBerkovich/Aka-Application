﻿using System;
using System.IO;

namespace monitor
{
    public class LogFilesManager
    {
        string logFilsLocation;
        double logFileSizeLimitation;
        string fileNamePrefix = "AcaMonitorLog";
        string currentFileName = string.Empty;
        const int baytInMegabayt = 1000000;
        static object @lock = new object();

        public LogFilesManager(string filesLocation, double fileSizeLimitation)
        {
            logFilsLocation = filesLocation;
            logFileSizeLimitation = fileSizeLimitation;
            Directory.CreateDirectory(filesLocation);
            currentFileName = logFilsLocation + @"\" + fileNamePrefix + DateTime.Now.ToString().Replace('/','_').Replace(':','_') + ".txt";
            File.Create(currentFileName);
        }

        public void WriteMessegeToLog(object Messege)
        {
            var currentMessege = (string)Messege;
            lock (@lock)

            {           
                FileInfo fileInfo = new FileInfo(currentFileName);
                if (fileInfo.Length > (logFileSizeLimitation * baytInMegabayt + currentMessege.Length * sizeof(Char)))
                {
                    currentFileName = logFilsLocation + @"\" + fileNamePrefix + DateTime.Now.ToString().Replace('/', '_').Replace(':', '_') + ".txt";
                }

                using (StreamWriter writetext = new StreamWriter(currentFileName, true))
                {
                    writetext.Write(currentMessege);
                }
            }

        }
    }
}
