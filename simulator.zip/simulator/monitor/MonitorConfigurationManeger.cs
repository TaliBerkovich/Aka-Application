﻿using System.IO;
using System.Text.Json;
using System;

namespace monitor
{
    public class MonitorConfigurationManeger
    {
        const string configFileName = @"..\..\..\config\AcaMonitorConfiguration.json";
        public AcaMonitorConfiguration monitorConfiguration { get; set; }

        public MonitorConfigurationManeger()
        {
            try
            {
                string jsonString = File.ReadAllText(configFileName);
                monitorConfiguration = JsonSerializer.Deserialize<AcaMonitorConfiguration>(jsonString);
            }
            catch(Exception e)
            {
                // Set default values in case of fail reading config file. 
                ///ToDo handle error case.
                monitorConfiguration = new AcaMonitorConfiguration
                {
                    IPAddress = "127.0.0.1",
                    Port = 5000,
                    MessagesNumberForUIDisplay = 10,
                    LogFileSizeLimitation = 300,
                    LogFilesPath = "logs",
                };
            }
            
        }
        public int GetNumMessagesForDisplay()
        {
            return monitorConfiguration.MessagesNumberForUIDisplay;
        }
    }

    public class AcaMonitorConfiguration
    {
        public string IPAddress { get; set; }
        public int Port { get; set; }
        public int MessagesNumberForUIDisplay { get; set; }
        public double LogFileSizeLimitation { get; set; }
        public string LogFilesPath { get; set; }
    }
}
