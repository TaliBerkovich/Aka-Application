﻿using System.Threading;

namespace monitor
{
    public class MonitorManager
    {
        TCPServerManager tcpServer;
        MonitorConfigurationManeger configurationManeger;
        LogFilesManager logsManeger;
        public event receivedMessage receiveMessageEvent;

        public void Run()
        {
            configurationManeger = new MonitorConfigurationManeger();
            tcpServer = new TCPServerManager(configurationManeger.monitorConfiguration.IPAddress, configurationManeger.monitorConfiguration.Port);
            tcpServer.receiveMessageEvent += ReceiveMessageEventHandler;
            logsManeger = new LogFilesManager(configurationManeger.monitorConfiguration.LogFilesPath, configurationManeger.monitorConfiguration.LogFileSizeLimitation);
            tcpServer.RunReceiveStream();
        }

        void ReceiveMessageEventHandler(string receivedData)
        {
            receiveMessageEvent?.Invoke(receivedData);
            Thread newThread = new Thread(logsManeger.WriteMessegeToLog);
            newThread.Start(receivedData);
        }

        public int GetUiConfiguration()
        {
            return configurationManeger.GetNumMessagesForDisplay();
        }

        public void CloseClient()
        {
            if (tcpServer != null)
                tcpServer.CloseClient();
        }

    }
}
