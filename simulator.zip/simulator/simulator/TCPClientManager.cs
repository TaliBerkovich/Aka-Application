﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace simulator
{
    public class TCPClientManager
    {

        TcpClient client;
        AcaSimulatorConfiguration conf;
        const string TextToSend = "Aka simulator message";
        const int Frequency = 10;

        public TCPClientManager (AcaSimulatorConfiguration configuration)
        {
            conf = configuration;
        }
        public void RunSentStream()
        {
            try
            {
                client = new TcpClient(conf.IPAddress, conf.Port);
                NetworkStream stream = client.GetStream();
                int counter = 0;

                while (true)
                {
                    Thread.Sleep(Frequency);
                    counter++;
                    string fullTextToSend = TextToSend + " " + counter.ToString() + System.Environment.NewLine;
                    byte[] bytesToSend = ASCIIEncoding.ASCII.GetBytes(fullTextToSend);
                    Console.WriteLine(fullTextToSend);
                    stream.Write(bytesToSend, 0, bytesToSend.Length);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("error: " + e);
                CloseClient();
            }
    }
            public void CloseClient()
            {
              if (client != null)
                  client.Close();
            }
        }
    }

