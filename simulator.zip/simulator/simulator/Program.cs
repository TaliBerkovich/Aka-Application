﻿using System;

namespace simulator
{
    class Program
    {
        static TCPClientManager tcpClient;
        static SimulatorConfigurationManeger config; 

        static void Main(string[] args)
        {
            AppDomain.CurrentDomain.ProcessExit += new EventHandler(CurrentDomain_ProcessExit);
            config = new SimulatorConfigurationManeger();
            tcpClient = new TCPClientManager(config.simulatorConfiguration);
            tcpClient.RunSentStream();
        }

        static void CurrentDomain_ProcessExit(object sender, EventArgs e)
        {
            tcpClient.CloseClient();
        }

    }
}




