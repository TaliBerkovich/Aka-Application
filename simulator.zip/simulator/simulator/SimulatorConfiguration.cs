﻿using System.IO;
using System.Text.Json;
using System;

namespace simulator
{
    public class SimulatorConfigurationManeger
    {
        const string configFileName = @"..\..\..\config\AcaSimulatorConfiguration.json";
        public AcaSimulatorConfiguration simulatorConfiguration { get; set; }
        public SimulatorConfigurationManeger()
        {
            try
            {
                string jsonString = File.ReadAllText(configFileName);
                simulatorConfiguration = JsonSerializer.Deserialize<AcaSimulatorConfiguration>(jsonString);
            }
            catch (Exception e)
            {
                // Set default values in case of fail reading config file. 
                ///ToDo handle error case.
                simulatorConfiguration = new AcaSimulatorConfiguration
                {
                    IPAddress = "127.0.0.1",
                    Port = 5000
                };
            }
        }
    }

    public class AcaSimulatorConfiguration
    {
        public string IPAddress { get; set; }
        public int Port { get; set; }

    }
}
