﻿using System.IO;
using System.Text.Json;

namespace JsonConfigurationCreator
{
    public class Program
    {
        static string MonitorConfigurationFileName = "AcaMonitorConfiguration.json";
        static string SimulatorConfigurationFileName = "AcaSimulatorConfiguration.json";
        static void Main(string[] args)
        {
            AcaMonitorConfiguration monitorConfiguration = new AcaMonitorConfiguration
            {
                IPAddress = "127.0.0.1",
                Port = 5000,
                MessagesNumberForUIDisplay = 20,
                LogFileSizeLimitation = 0.1,
                LogFilesPath = "logs"
            };

            AcaSimulatorConfiguration SimulatorConfiguration = new AcaSimulatorConfiguration
            {
                IPAddress = "127.0.0.1",
                Port = 5000
            };

            string jsonStringMonitor = JsonSerializer.Serialize(monitorConfiguration);
            File.WriteAllText(MonitorConfigurationFileName, jsonStringMonitor);

            string jsonString1Simulator = JsonSerializer.Serialize(SimulatorConfiguration);
            File.WriteAllText(SimulatorConfigurationFileName, jsonString1Simulator);
        }
    }

    public class AcaMonitorConfiguration
    {
        public string IPAddress { get; set; }
        public int Port { get; set; }
        public int MessagesNumberForUIDisplay { get; set; }
        public double LogFileSizeLimitation { get; set; }
        public string LogFilesPath { get; set; }
    }

    public class AcaSimulatorConfiguration
    {
        public string IPAddress { get; set; }
        public int Port { get; set; }

    }
}
